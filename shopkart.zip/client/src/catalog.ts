export type CatalogCategory = 'Mobiles' | 'Laptops' | 'Electronics' | 'Headphones' | 'Smartwatches' | 'Fashion' | 'Home & Kitchen' | 'Books' | 'Grocery' | 'Accessories' | 'Computer Components' | 'Gaming';

export type CatalogProduct = {
  id: number;
  title: string;
  category: CatalogCategory;
  brand: string;
  price: number;
  original: number;
  rating: number;
  reviews: number;
  badge?: string;
  description: string;
  specs: string[];
  image: string;
  fallbackImage: string;
  accent: string;
  stock: number;
  searchTerms: string[];
};

const imagePools: Record<CatalogCategory, string[]> = {
  Mobiles: [
    'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1556656793-08538906a9f8?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=900&q=85'
  ],
  Laptops: [
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=85'
  ],
  Electronics: [
    'https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=85'
  ],
  Headphones: [
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1577174881658-0f30ed549adc?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=900&q=85'
  ],
  Smartwatches: [
    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1544117519-31a4b719223d?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?auto=format&fit=crop&w=900&q=85'
  ],
  Fashion: [
    'https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=900&q=85'
  ],
  'Home & Kitchen': [
    'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=900&q=85'
  ],
  Books: [
    'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1519682337058-a94d519337bc?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1526243741027-444d633d7365?auto=format&fit=crop&w=900&q=85'
  ],
  Grocery: [
    'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1606787366850-de6330128bfc?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1550989460-0adf9ea622e2?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=900&q=85'
  ],
  Accessories: [
    'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1509695507497-903c140c43b0?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=900&q=85'
  ],
  'Computer Components': [
    'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1562976540-1502c2145186?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1555617778-02518510b9fa?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1587202372634-32705e3bf49c?auto=format&fit=crop&w=900&q=85'
  ],
  Gaming: [
    'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1560419015-7c427e8ae5ba?auto=format&fit=crop&w=900&q=85',
    'https://images.unsplash.com/photo-1603481546238-487240415921?auto=format&fit=crop&w=900&q=85'
  ]
};

const accents = ['#f5dd9e', '#d8e4df', '#e9c5ba', '#cdd7ea'];
const seeds: Array<[CatalogCategory, string[]]> = [
  ['Mobiles', ['Mobile', 'Smartphone', 'Mobile Accessories', 'Smartphone Pro']],
  ['Laptops', ['Laptop', 'Gaming Laptop', 'Laptop Stand', 'Laptop Bag']],
  ['Electronics', ['Bluetooth Speaker', 'Camera', 'Tablet', 'Power Bank']],
  ['Headphones', ['Headphones', 'Earbuds', 'Headset', 'Gaming Headphones']],
  ['Smartwatches', ['Smartwatch', 'Fitness Watch', 'Sport Watch', 'Wearable']],
  ['Fashion', ['T-Shirt', 'Shirt', 'Jeans', 'Shoes', 'Sneakers', 'Hoodie', 'Jacket', 'Backpack', 'Sunglasses']],
  ['Home & Kitchen', ['Refrigerator', 'Washing Machine', 'Microwave', 'Mixer Grinder', 'Air Conditioner', 'Fan', 'Cookware', 'Sofa', 'Chair', 'Kitchen Appliance']],
  ['Books', ['Python Book', 'Java Book', 'SQL Book', 'Data Science Book', 'Machine Learning Book', 'AI Book', 'Programming Book', 'Engineering Book']],
  ['Grocery', ['Coffee', 'Tea', 'Olive Oil', 'Pasta', 'Granola', 'Spices', 'Snacks', 'Fresh Produce']],
  ['Accessories', ['Phone Case', 'Backpack', 'Sunglasses', 'Travel Organizer', 'Wallet', 'Cable', 'Desk Accessory', 'Phone Strap']],
  ['Computer Components', ['RAM', 'SSD', 'Hard Disk', 'Graphics Card', 'Processor', 'Motherboard', 'Cabinet', 'Power Supply', 'Keyboard', 'Mouse']],
  ['Gaming', ['Gaming Mouse', 'Gaming Keyboard', 'Gaming Headset', 'Gaming Controller', 'Gaming Monitor', 'Gaming Accessories']]
];
const brandsByCategory: Record<CatalogCategory, string[]> = {
  Mobiles: ['Nova', 'Pixel', 'Aster', 'Lumen', 'Orbit', 'Vera', 'Mobi', 'Zenith', 'Nexis', 'Halo', 'Clover', 'Mira', 'Pico', 'Sora', 'Tide', 'Vertex', 'Kite', 'Ember', 'Civic', 'Axiom'],
  Laptops: ['Aero', 'Slate', 'Nova', 'Field', 'Arc', 'Morrow', 'Civic', 'Lumen', 'Peak', 'Drift', 'Orbit', 'Nexis', 'Atlas', 'Kindred', 'Sonder', 'North', 'Forma', 'Sage', 'Mica', 'Vela'],
  Electronics: ['Signal', 'Echo', 'Cove', 'Bright', 'Hush', 'Pulse', 'Arc', 'Mori', 'Relay', 'Halo', 'Trestle', 'Grove', 'Field', 'Lilt', 'Sonder', 'Vox', 'Rook', 'Dawn', 'Moss', 'Forma'],
  Headphones: ['Cove', 'Sonora', 'Aural', 'Mellow', 'Drift', 'Echo', 'Luma', 'Quiet', 'Sonic', 'Velvet', 'Hush', 'Aura', 'North', 'Kindred', 'Sora', 'Field', 'Solace', 'Bloom', 'Mira', 'Zenith'],
  Smartwatches: ['Daymark', 'Orbit', 'Pulse', 'Sundial', 'Field', 'Tempo', 'Atlas', 'Morrow', 'Aster', 'Civic', 'Lumen', 'Ridge', 'North', 'Tide', 'Forma', 'Halo', 'Peak', 'Vertex', 'Sora', 'Kindred'],
  Fashion: ['Moss & Morrow', 'Kindred', 'Lumen', 'Civic', 'Drift', 'Sonder', 'Mica', 'North', 'Paloma', 'Wander', 'Field', 'Grove', 'Ridge', 'Meadow', 'Tidepool', 'Forma', 'Aster', 'Solace', 'Mori', 'Cove'],
  'Home & Kitchen': ['Arc', 'Grove', 'Hearthstone', 'Forma', 'Sunroom', 'Bask', 'Ripple', 'Mica', 'Field Notes', 'Stillwater', 'Kindred', 'Luma', 'Mori', 'Trestle', 'Paloma', 'Cove', 'Meadow', 'Terra', 'Sonder', 'North Star'],
  Books: ['Small Rituals', 'Good Ideas', 'Paper Plane', 'North Star', 'Weekend Cook', 'Quiet Hours', 'Field Notes', 'Long Way Home', 'Slow Living', 'Common Table', 'Little Atlas', 'Soft Edges', 'Bright Future', 'The Daily Edit', 'Wild Garden', 'Everyday Wonder', 'Homeward', 'Open Roads', 'Makers', 'Kindred Pages'],
  Grocery: ['Mori', 'Meadow', 'Hearth', 'Grove', 'Sunroom', 'Kindred', 'Civic', 'Field', 'Terra', 'Good Table', 'Stillwater', 'North Star', 'Mellow', 'Sonder', 'Lumen', 'Paloma', 'Ridge', 'Tide', 'Cove', 'Forma'],
  Accessories: ['Folio', 'Canvas', 'Lilt', 'Atlas', 'Quill', 'Ripple', 'Mica', 'Ridge', 'Civic', 'Lumen', 'Arc', 'Morrow', 'Kindred', 'North', 'Sonder', 'Trestle', 'Paloma', 'Terra', 'Field', 'Grove'],
  'Computer Components': ['Orbit', 'Pixel', 'Signal', 'Relay', 'Forma', 'Arcade', 'Nexis', 'Civic', 'Axiom', 'Luma', 'Trestle', 'Vertex', 'Slate', 'Mica', 'North', 'Peak', 'Bright', 'Cove', 'Drift', 'Halo'],
  Gaming: ['Arcade', 'Pixel', 'Quest', 'Level', 'Rift', 'Nova', 'Civic', 'Orbit', 'Signal', 'Morrow', 'Vertex', 'Axiom', 'Drift', 'Halo', 'Lumen', 'Nexis', 'Peak', 'Rook', 'Pulse', 'Echo']
};
const descriptors = ['Everyday', 'Studio', 'Essential', 'Pocket', 'Pro', 'Quiet', 'Smart', 'Classic', 'Prime', 'Travel', 'Cloud', 'Canyon', 'Select', 'Modern', 'Field', 'Daily', 'Bright', 'Calm', 'Urban', 'Summit'];
const suffixes = ['Series', 'Edit', 'Collection', 'Kit', 'One', 'Plus', 'Air', 'Max', 'Mini', 'Set', 'Core', 'Lite'];
const categoryAliases: Record<CatalogCategory, string[]> = {
  Mobiles: ['mobile', 'smartphone', 'iphone', 'samsung', 'oneplus', 'xiaomi', 'redmi', 'realme', 'vivo', 'oppo', 'motorola', 'google pixel', 'mobile accessories'],
  Laptops: ['laptop', 'gaming laptop', 'laptop bag', 'laptop stand', 'dell', 'hp', 'lenovo', 'asus', 'acer', 'apple', 'msi'],
  Electronics: ['electronics', 'bluetooth speaker', 'camera', 'tablet', 'power bank', 'charger', 'monitor'],
  Headphones: ['headphones', 'headphone', 'earbuds', 'headset', 'gaming headphones'],
  Smartwatches: ['smartwatch', 'fitness watch', 'sport watch', 'wearable'],
  Fashion: ['fashion', 't-shirt', 'shirt', 'jeans', 'shoes', 'sneakers', 'hoodie', 'jacket', 'backpack', 'sunglasses'],
  'Home & Kitchen': ['home', 'kitchen', 'refrigerator', 'washing machine', 'microwave', 'mixer grinder', 'air conditioner', 'fan', 'cookware', 'sofa', 'chair'],
  Books: ['book', 'books', 'python book', 'java book', 'sql book', 'data science book', 'machine learning book', 'ai book', 'programming book', 'engineering book'],
  Grocery: ['grocery', 'coffee', 'tea', 'olive oil', 'pasta', 'granola', 'spices', 'snacks', 'fresh produce'],
  Accessories: ['accessories', 'phone case', 'backpack', 'sunglasses', 'travel organizer', 'wallet', 'cable', 'phone strap'],
  'Computer Components': ['computer components', 'ram', 'ssd', 'hard disk', 'graphics card', 'processor', 'motherboard', 'cabinet', 'power supply', 'keyboard', 'mouse'],
  Gaming: ['gaming', 'gaming mouse', 'gaming keyboard', 'gaming headset', 'gaming controller', 'gaming monitor', 'gaming accessories']
};

export const products: CatalogProduct[] = seeds.flatMap(([category, subcategories], categoryIndex) => brandsByCategory[category].map((brand, index) => {
  const id = categoryIndex * 20 + index + 1;
  const subcategory = subcategories[index % subcategories.length];
  const price = 18 + ((id * 37) % 68) * 5 + (index % 3) * 9;
  const original = Math.round(price * (1.18 + (id % 5) * 0.07));
  const title = `${brand} ${descriptors[(id + categoryIndex) % descriptors.length]} ${subcategory} ${suffixes[(id * 3) % suffixes.length]}`;
  const pool = imagePools[category];
  const image = pool[index % pool.length];
  return {
    id,
    title,
    category,
    brand,
    price,
    original,
    rating: Number((4 + ((id * 7) % 10) / 10).toFixed(1)),
    reviews: 34 + ((id * 83) % 4800),
    badge: id < 9 ? (id % 2 ? 'New drop' : 'Bestseller') : id % 11 === 0 ? 'Limited' : undefined,
    description: `A thoughtfully designed ${title.toLowerCase()} by ${brand}, made for everyday use. Crafted with practical details, dependable materials, and a little extra delight.`,
    specs: [`${brand} considered construction`, `${subcategory} ready for daily use`, 'Packed in recyclable materials'],
    image,
    fallbackImage: pool[0],
    accent: accents[(id - 1) % accents.length],
    stock: id % 17 === 0 ? 3 : 12 + ((id * 11) % 72),
    searchTerms: [...categoryAliases[category], subcategory.toLowerCase(), ...(category === 'Mobiles' ? ['samsung', 'iphone'] : [])]
  };
}));

export const categoryNames = seeds.map(([category]) => category);
export const searchProducts = (query: string, source = products) => {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return source;
  return source.filter(product => [product.title, product.category, product.brand, product.description, ...product.specs, ...product.searchTerms].join(' ').toLowerCase().includes(normalized));
};
export const discount = (product: CatalogProduct) => Math.round((1 - product.price / product.original) * 100);
